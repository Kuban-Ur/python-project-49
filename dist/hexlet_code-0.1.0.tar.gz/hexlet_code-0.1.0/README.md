### Hexlet tests and linter status:
[![Actions Status](https://github.com/Kuban-Ur/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Kuban-Ur/python-project-49/actions)