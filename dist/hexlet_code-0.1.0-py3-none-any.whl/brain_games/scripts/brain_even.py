#!/usr/bin/env python3
from brain_games.games.even import b_even



def main():
    print('Welcome to the Brain Games!')
    b_even()


if __name__ == '__main__':
    main()
